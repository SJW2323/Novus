NOVUS — PRESS & BRAND KIT
==========================

BOILERPLATE
-----------
Novus is a live, face-to-face AI tutor for A-level Biology. Instead of
typing into a chatbot, students talk to Novus on a call, mapped exactly
to their exam board's specification (AQA, WJEC, with OCR and Edexcel on
the roadmap), and it remembers what was covered and how each student
learns from one session to the next. Novus was founded by two Biology
students who kept running into the same problem while tutoring others:
almost every resource is written for "A-level Biology" in the abstract,
not for the exam board actually in front of a student.

BRAND COLOURS
-------------
Background   #050E1A
Blue         #4C99F8
Purple       #A657ED

LOGO USAGE
----------
Keep clear space around the mark. Do not recolour it or place it on a
background that doesn't give it enough contrast.

CONTACT
-------
samjwalters23@gmail.com

WEBSITE
-------
https://novus-murex.vercel.app
